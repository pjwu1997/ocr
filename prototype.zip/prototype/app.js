const workflowSteps = [
  "建案資料",
  "文件上傳",
  "OCR 辨識",
  "規則判斷",
  "人工覆核",
  "確認存檔",
  "分發通知",
  "稽核軌跡"
];

const scenarioTemplates = [
  {
    no: 1,
    name: "接駁車",
    docs: ["接駁車搭乘登記表"],
    fields: ["路線名稱", "登記人數", "實際搭乘人數"],
    aiSamples: ["中科線A", "32", "27"],
    rules: ["登記 > 實搭警示"]
  },
  {
    no: 2,
    name: "用餐調整表",
    docs: ["用餐費用調整表"],
    fields: ["餐廳", "卡號", "姓名", "用餐日期", "調整數量(+1/-1)", "餐別", "調整原因"],
    aiSamples: ["A 棟餐廳", "A01935", "李佳欣", "2026/02/21", "+1", "午餐", "加班"],
    rules: ["卡號姓名一致", "欄位完整性"]
  },
  {
    no: 3,
    name: "員工子女教托育補助",
    docs: ["註冊費/托嬰費收據", "關係證明"],
    fields: ["繳費金額", "申請金額", "姓名", "關係資訊"],
    aiSamples: ["28,000", "20,000", "王小明", "父女"],
    rules: ["繳費總額 >= 申請金額"]
  },
  {
    no: 4,
    name: "教育獎學金",
    docs: ["成績單", "關係證明"],
    fields: ["學生姓名", "科目分數", "總分/平均"],
    aiSamples: ["王小華", "89, 92, 94", "91.7"],
    rules: ["分數達門檻", "無總分時計算平均"]
  },
  {
    no: 5,
    name: "員工進修補助金",
    docs: ["註冊費收據"],
    fields: ["學生姓名", "員工姓名", "學期", "繳費總額", "申請金額"],
    aiSamples: ["陳冠宇", "陳冠宇", "114-2", "42,000", "20,000"],
    rules: ["學生需為員工本人", "學期在申請範圍", "繳費總額 >= 申請金額"]
  },
  {
    no: 6,
    name: "清潔打卡資料",
    docs: ["清潔人員出勤卡"],
    fields: ["姓名", "每日上下班時間"],
    aiSamples: ["張美玲", "08:03 / 17:11"],
    rules: ["時間格式檢核", "缺漏欄位檢核"]
  },
  {
    no: 7,
    name: "結婚慶賀金",
    docs: ["喜帖", "結婚證書", "關係證明"],
    fields: ["員工姓名", "配偶姓名", "宴客日期", "結婚生效日"],
    aiSamples: ["王小明", "林小雅", "2026/01/18", "2026/01/10"],
    rules: ["生效日 > 1 年警示", "跨文件姓名一致"]
  },
  {
    no: 8,
    name: "喪葬奠儀",
    docs: ["訃聞", "死亡證明", "關係證明"],
    fields: ["員工姓名", "儀式日期", "儀式地點"],
    aiSamples: ["陳明德", "2026/02/03", "台中市北區"],
    rules: ["必填欄位檢核", "日期有效性"]
  },
  {
    no: 9,
    name: "生育慶賀金",
    docs: ["戶籍謄本", "出生證明"],
    fields: ["姓名", "記事內容", "出生日期"],
    aiSamples: ["李佩珊", "長女出生登記", "2026/02/14"],
    rules: ["出生日期辨識與格式檢核"]
  },
  {
    no: 10,
    name: "活動請款",
    docs: ["發票", "收據"],
    fields: ["消費日期", "買方資訊", "消費金額", "申請金額"],
    aiSamples: ["2026/02/18", "福委會 / 12345678", "8,900", "8,000"],
    rules: ["消費金額 > 申請金額", "買方資訊格式"]
  },
  {
    no: 11,
    name: "急難救助金",
    docs: ["診斷證明"],
    fields: ["員工姓名", "應診日期", "醫師囑言"],
    aiSamples: ["張雅婷", "2026/02/19", "建議休養 7 日"],
    rules: ["內容需含必要日期"]
  },
  {
    no: 12,
    name: "公文分發",
    docs: ["公文"],
    fields: ["發文者", "發文日期", "發文字號", "主旨", "說明", "是否罰款", "兩字關鍵字"],
    aiSamples: ["台中市政府", "2026/02/22", "府授法字第123號", "限期改善", "逾期裁罰", "是", "罰款"],
    rules: ["關鍵字分發", "罰款條件路由"]
  },
  {
    no: 13,
    name: "郵件分發",
    docs: ["郵件信封"],
    fields: ["掛號號碼", "寄件者", "收件者姓名", "收件部門"],
    aiSamples: ["RR123456789TW", "台中地院", "王主任", "法務部門"],
    rules: ["收件者映射窗口"]
  },
  {
    no: 14,
    name: "廠商合約",
    docs: ["特約商合約"],
    fields: ["到期日", "廠商名稱", "電話", "優惠方案"],
    aiSamples: ["2027/03/31", "XX 餐飲公司", "04-12345678", "員工 9 折"],
    rules: ["到期提醒", "電話格式"]
  },
  {
    no: 15,
    name: "矽品特約合約書",
    docs: ["合約文件", "優惠內容"],
    fields: ["優惠條款", "勾選項目"],
    aiSamples: ["假日 85 折", "餐飲類"],
    rules: ["文字映射勾選欄位"]
  },
  {
    no: 16,
    name: "例行表單寄送",
    docs: ["巡檢表", "體檢表", "例行文件"],
    fields: ["文件標題", "文件類型", "日期", "對應窗口"],
    aiSamples: ["廚房衛生巡檢", "巡檢表", "2026/02/20", "總務窗口"],
    rules: ["標題自動命名", "自動路由寄送"]
  }
];

const cases = [
  {
    id: "CASE-2026-00018",
    item: "10. 活動請款",
    applicant: "王小明",
    owner: "GA 承辦 A",
    amount: "8,000",
    status: "待覆核",
    currentStep: 4,
    docs: [
      { name: "活動發票.png", uploader: "王小明", at: "2026-02-22 09:12", scan: "通過", type: "發票" },
      { name: "請款申請單.pdf", uploader: "王小明", at: "2026-02-22 09:13", scan: "通過", type: "申請單" }
    ],
    ocrFields: [
      { field: "消費日期", ai: "2026/02/18", confidence: 0.98, human: "2026/02/18" },
      { field: "買方統編", ai: "1234567B", confidence: 0.62, human: "12345678" },
      { field: "消費金額", ai: "8,900", confidence: 0.99, human: "8,900" },
      { field: "申請金額", ai: "8,000", confidence: 0.99, human: "8,000" }
    ],
    rules: [
      { name: "消費金額 > 申請金額", status: "ok", note: "8,900 > 8,000" },
      { name: "買方統編格式檢核", status: "warn", note: "AI 抽取含字母，需人工修正" }
    ],
    syncs: [
      { target: "福利平台", status: "pending", detail: "等待確認存檔後回寫" },
      { target: "Email 管理", status: "pending", detail: "尚未觸發通知" }
    ],
    timeline: [
      { at: "2026-02-22 09:10", by: "王小明", action: "建立案件" },
      { at: "2026-02-22 09:13", by: "王小明", action: "上傳 2 份附件" },
      { at: "2026-02-22 09:15", by: "系統", action: "OCR 完成，1 筆欄位低信心" },
      { at: "2026-02-22 09:20", by: "GA 承辦 A", action: "進入人工覆核" }
    ]
  },
  {
    id: "CASE-2026-00023",
    item: "2. 用餐調整表",
    applicant: "李佳欣",
    owner: "GA 承辦 B",
    amount: "N/A",
    status: "退補件",
    currentStep: 1,
    docs: [
      { name: "用餐費用調整表.pdf", uploader: "李佳欣", at: "2026-02-22 10:05", scan: "通過", type: "調整表" }
    ],
    ocrFields: [
      { field: "卡號", ai: "A0193S", confidence: 0.68, human: "A01935" },
      { field: "姓名", ai: "李佳妡", confidence: 0.71, human: "李佳欣" },
      { field: "用餐日期", ai: "2026/02/21", confidence: 0.94, human: "2026/02/21" }
    ],
    rules: [
      { name: "卡號與員工主檔一致", status: "bad", note: "員工主檔無 A0193S" },
      { name: "必填欄位完整", status: "warn", note: "調整原因未填寫" }
    ],
    syncs: [
      { target: "伙食系統", status: "hold", detail: "退補件，不同步" }
    ],
    timeline: [
      { at: "2026-02-22 10:03", by: "李佳欣", action: "建立案件" },
      { at: "2026-02-22 10:05", by: "李佳欣", action: "上傳調整表" },
      { at: "2026-02-22 10:09", by: "系統", action: "規則判斷失敗，待補件" }
    ]
  },
  {
    id: "CASE-2026-00031",
    item: "12. 公文分發",
    applicant: "總務窗口",
    owner: "文管中心",
    amount: "N/A",
    status: "已確認",
    currentStep: 7,
    docs: [
      { name: "公文.pdf", uploader: "總務窗口", at: "2026-02-22 11:02", scan: "通過", type: "公文" }
    ],
    ocrFields: [
      { field: "發文者", ai: "台中市政府", confidence: 0.99, human: "台中市政府" },
      { field: "發文字號", ai: "府授法字第123號", confidence: 0.96, human: "府授法字第123號" },
      { field: "兩字關鍵字", ai: "罰款", confidence: 0.92, human: "罰款" },
      { field: "目標窗口", ai: "法務窗口", confidence: 0.95, human: "法務窗口" }
    ],
    rules: [
      { name: "關鍵字路由命中", status: "ok", note: "罰款 -> 法務窗口" },
      { name: "分發窗口有效性", status: "ok", note: "窗口已啟用" }
    ],
    syncs: [
      { target: "分發/窗口平台", status: "ok", detail: "已成功建立分發任務" },
      { target: "Email 管理", status: "ok", detail: "已寄送通知，追蹤碼 EM-2319" }
    ],
    timeline: [
      { at: "2026-02-22 11:01", by: "總務窗口", action: "建立案件與上傳公文" },
      { at: "2026-02-22 11:04", by: "系統", action: "OCR 完成並觸發規則分發" },
      { at: "2026-02-22 11:07", by: "文管中心", action: "人工覆核通過並確認存檔" },
      { at: "2026-02-22 11:08", by: "系統", action: "完成分發與 Email 通知" }
    ]
  }
];

const refs = {
  caseCards: document.getElementById("caseCards"),
  caseTitle: document.getElementById("caseTitle"),
  caseMeta: document.getElementById("caseMeta"),
  caseStatus: document.getElementById("caseStatus"),
  stepper: document.getElementById("stepper"),
  stepContent: document.getElementById("stepContent"),
  prevStepBtn: document.getElementById("prevStepBtn"),
  nextStepBtn: document.getElementById("nextStepBtn"),
  createCaseBtn: document.getElementById("createCaseBtn"),
  tabBtns: document.querySelectorAll(".tab-btn"),
  operationView: document.getElementById("operationView"),
  adminView: document.getElementById("adminView"),
  toast: document.getElementById("toast"),
  templateSelector: document.getElementById("templateSelector"),
  catalogFields: document.getElementById("catalogFields"),
  catalogAI: document.getElementById("catalogAI"),
  catalogRules: document.getElementById("catalogRules"),
  catalogFlow: document.getElementById("catalogFlow")
};

let activeCaseId = cases[0].id;
let activeStep = cases[0].currentStep;

function activeCase() {
  return cases.find((x) => x.id === activeCaseId);
}

function templateLabel(tpl) {
  return `${tpl.no}. ${tpl.name}`;
}

function templateByCaseItem(item) {
  const no = Number(String(item).split(".")[0].trim());
  const found = scenarioTemplates.find((x) => x.no === no);
  return found || scenarioTemplates[0];
}

function templateSampleValue(tpl, fieldName, idx) {
  if (!tpl || !tpl.aiSamples || tpl.aiSamples.length === 0) return "-";
  if (idx < tpl.aiSamples.length) return tpl.aiSamples[idx];
  const mappedIdx = tpl.fields.indexOf(fieldName);
  return mappedIdx >= 0 && mappedIdx < tpl.aiSamples.length ? tpl.aiSamples[mappedIdx] : "-";
}

function applyTemplateToCase(caseObj, tpl, force = false) {
  caseObj.item = templateLabel(tpl);
  if (force || caseObj.ocrFields.length === 0) {
    caseObj.ocrFields = tpl.fields.map((f, idx) => ({
      field: f,
      ai: templateSampleValue(tpl, f, idx),
      confidence: 0.9,
      human: templateSampleValue(tpl, f, idx)
    }));
  }
  if (force || caseObj.rules.length === 0) {
    caseObj.rules = tpl.rules.map((r) => ({
      name: r,
      status: "warn",
      note: "待 OCR 與規則引擎執行"
    }));
  }
  if (force || caseObj.docs.length === 0) {
    caseObj.docs = tpl.docs.map((d, idx) => ({
      name: `${d}_${idx + 1}.pdf`,
      uploader: caseObj.owner,
      at: "2026-02-22 21:50",
      scan: "待上傳",
      type: d
    }));
  }
}

function showToast(message) {
  refs.toast.textContent = message;
  refs.toast.classList.add("show");
  window.setTimeout(() => refs.toast.classList.remove("show"), 1700);
}

function statusClass(status) {
  if (status.includes("確認")) return "ok";
  if (status.includes("退")) return "bad";
  return "warn";
}

function syncClass(status) {
  if (status === "ok") return "ok";
  if (status === "bad") return "bad";
  return "warn";
}

function renderCaseCards() {
  refs.caseCards.innerHTML = "";
  for (const c of cases) {
    const div = document.createElement("div");
    div.className = `case-card ${c.id === activeCaseId ? "active" : ""}`;
    div.innerHTML = `
      <div class="case-id">${c.id}</div>
      <div class="case-line">${c.item}</div>
      <div class="case-line">申請人：${c.applicant}</div>
      <div class="case-line">狀態：${c.status}</div>
    `;
    div.addEventListener("click", () => {
      activeCaseId = c.id;
      activeStep = c.currentStep;
      renderAll();
    });
    refs.caseCards.appendChild(div);
  }
}

function renderSummary() {
  const c = activeCase();
  refs.caseTitle.textContent = `${c.id} / ${c.item}`;
  refs.caseMeta.textContent = `申請人：${c.applicant} ｜ 承辦：${c.owner}`;
  refs.caseStatus.textContent = c.status;
  refs.caseStatus.className = `badge ${statusClass(c.status)}`;
}

function renderStepper() {
  refs.stepper.innerHTML = "";
  workflowSteps.forEach((s, idx) => {
    const step = document.createElement("div");
    step.className = `step ${idx === activeStep ? "active" : ""} ${idx < activeStep ? "done" : ""}`;
    step.innerHTML = `${idx + 1}. ${s}`;
    step.addEventListener("click", () => {
      activeStep = idx;
      renderAll();
    });
    refs.stepper.appendChild(step);
  });
}

function renderTemplateCatalogPanel(forceNo) {
  if (!refs.templateSelector) return;

  const current = forceNo || Number(refs.templateSelector.value) || scenarioTemplates[0].no;
  refs.templateSelector.innerHTML = scenarioTemplates
    .map((tpl) => `<option value="${tpl.no}" ${tpl.no === current ? "selected" : ""}>${templateLabel(tpl)}</option>`)
    .join("");

  const selected = scenarioTemplates.find((x) => x.no === Number(refs.templateSelector.value)) || scenarioTemplates[0];

  refs.catalogFields.innerHTML = selected.fields.map((f) => `<div>${f}</div>`).join("");
  refs.catalogAI.innerHTML = selected.fields
    .map((f, idx) => `<div>${f}：${templateSampleValue(selected, f, idx)}</div>`)
    .join("");
  refs.catalogRules.innerHTML = selected.rules.map((r) => `<div>${r}</div>`).join("");
  refs.catalogFlow.innerHTML = workflowSteps.map((s, i) => `<span>${i + 1}. ${s}</span>`).join("");
}

function fieldRows(fields, mode = "ocr") {
  const head = mode === "ocr"
    ? `<div class="row head row field"><div>欄位</div><div>AI 抽取值</div><div>信心</div></div>`
    : `<div class="row head row review"><div>欄位</div><div>AI 原值</div><div>人工確認值</div></div>`;

  const rows = fields.map((f, i) => {
    if (mode === "ocr") {
      const low = f.confidence < 0.8 ? "low-confidence" : "";
      return `
        <div class="row row field">
          <div>${f.field}</div>
          <div class="mono">${f.ai}</div>
          <div class="${low}">${Math.round(f.confidence * 100)}%</div>
        </div>
      `;
    }
    return `
      <div class="row row review">
        <div>${f.field}</div>
        <div class="mono">${f.ai}</div>
        <div><input class="text-input review-input" data-index="${i}" value="${f.human}" /></div>
      </div>
    `;
  }).join("");

  return `<div class="table-wrap">${head}${rows}</div>`;
}

function renderStepContent() {
  const c = activeCase();
  const step = activeStep;
  let html = "";

  if (step === 0) {
    const tpl = templateByCaseItem(c.item);
    const options = scenarioTemplates
      .map((x) => `<option value="${x.no}" ${x.no === tpl.no ? "selected" : ""}>${templateLabel(x)}</option>`)
      .join("");
    html = `
      <p class="section-title">建案資料</p>
      <div class="info-grid">
        <div class="info-card">
          <label>案件編號</label>
          <input class="text-input" value="${c.id}" readonly />
        </div>
        <div class="info-card">
          <label>項目類型</label>
          <select id="caseItemSelect" class="select-input">${options}</select>
        </div>
        <div class="info-card">
          <label>申請人</label>
          <input class="text-input" value="${c.applicant}" />
        </div>
      </div>
      <div class="catalog-grid" style="margin-top:10px;">
        <div class="info-card">
          <div class="section-title">此項目必抽欄位</div>
          <div class="mini-list-col">${tpl.fields.map((f) => `<div>${f}</div>`).join("")}</div>
        </div>
        <div class="info-card">
          <div class="section-title">此項目 AI 抽取值</div>
          <div class="mini-list-col">${tpl.fields.map((f, idx) => `<div>${f}：${templateSampleValue(tpl, f, idx)}</div>`).join("")}</div>
        </div>
        <div class="info-card">
          <div class="section-title">此項目規則</div>
          <div class="mini-list-col">${tpl.rules.map((r) => `<div>${r}</div>`).join("")}</div>
        </div>
      </div>
      <div class="info-card" style="margin-top:10px;">
        <div class="section-title">標準流程</div>
        <div class="flow-list">${workflowSteps.map((s, i) => `<span>${i + 1}. ${s}</span>`).join("")}</div>
      </div>
      <div class="inline-actions">
        <button class="btn-ghost" data-action="saveDraft">儲存草稿</button>
      </div>
    `;
  }

  if (step === 1) {
    const docs = c.docs.map((d) => `
      <div class="doc-item">
        <div>
          <div><b>${d.name}</b> <span class="sub">(${d.type})</span></div>
          <div class="sub">上傳者：${d.uploader} ｜ ${d.at}</div>
        </div>
        <span class="state ${d.scan === "通過" ? "ok" : d.scan === "待上傳" ? "warn" : "bad"}">${d.scan}</span>
      </div>
    `).join("");
    html = `
      <p class="section-title">文件上傳與防毒掃描</p>
      <div class="doc-list">${docs}</div>
      <div class="inline-actions">
        <button class="btn-ghost" data-action="mockUpload">模擬上傳文件</button>
      </div>
    `;
  }

  if (step === 2) {
    html = `
      <p class="section-title">OCR 辨識結果與信心分數</p>
      ${fieldRows(c.ocrFields, "ocr")}
      <div class="inline-actions">
        <button class="btn-ghost" data-action="rerunOCR">重跑 OCR</button>
      </div>
    `;
  }

  if (step === 3) {
    const rules = c.rules.map((r) => `
      <div class="rule-item">
        <div>
          <div><b>${r.name}</b></div>
          <div class="sub">${r.note}</div>
        </div>
        <span class="state ${r.status}">${r.status === "ok" ? "通過" : r.status === "warn" ? "警示" : "失敗"}</span>
      </div>
    `).join("");
    html = `
      <p class="section-title">規則判斷結果</p>
      <div class="rule-list">${rules}</div>
      <div class="inline-actions">
        <button class="btn-ghost" data-action="rerunRules">重新判斷</button>
      </div>
    `;
  }

  if (step === 4) {
    html = `
      <p class="section-title">人工覆核（可修改欄位）</p>
      ${fieldRows(c.ocrFields, "review")}
      <div class="info-card" style="margin-top:10px;">
        <label>修正說明</label>
        <textarea class="text-area" id="editReason" placeholder="請填寫修正原因（例如：手寫辨識誤差）"></textarea>
      </div>
      <div class="inline-actions">
        <button class="btn-ghost" data-action="saveReview">儲存覆核內容</button>
      </div>
    `;
  }

  if (step === 5) {
    html = `
      <p class="section-title">確認存檔</p>
      <div class="info-grid">
        <div class="info-card">
          <label>案件狀態</label>
          <input class="text-input" value="${c.status}" readonly />
        </div>
        <div class="info-card">
          <label>確認後狀態</label>
          <input class="text-input" value="已確認" readonly />
        </div>
      </div>
      <div class="info-card" style="margin-top:10px;">
        <label>覆核備註</label>
        <textarea class="text-area" id="archiveNote" placeholder="輸入確認備註"></textarea>
      </div>
      <div class="inline-actions">
        <button class="btn-danger" data-action="requestFix">退補件</button>
        <button class="btn-primary" data-action="confirmArchive">確認存檔</button>
      </div>
    `;
  }

  if (step === 6) {
    const syncs = c.syncs.map((s) => `
      <div class="sync-item">
        <div>
          <div><b>${s.target}</b></div>
          <div class="sub">${s.detail}</div>
        </div>
        <span class="state ${syncClass(s.status)}">${s.status}</span>
      </div>
    `).join("");
    html = `
      <p class="section-title">分發通知與平台同步</p>
      <div class="sync-list">${syncs}</div>
      <div class="inline-actions">
        <button class="btn-ghost" data-action="retrySync">重送同步</button>
      </div>
    `;
  }

  if (step === 7) {
    const logs = c.timeline.map((t) => `
      <div class="timeline-item">
        <div>
          <div><b>${t.action}</b></div>
          <div class="sub">${t.by} ｜ ${t.at}</div>
        </div>
      </div>
    `).join("");
    html = `
      <p class="section-title">稽核軌跡（操作留痕）</p>
      <div class="timeline">${logs}</div>
    `;
  }

  refs.stepContent.innerHTML = html;
  bindDynamicEvents();
}

function bindDynamicEvents() {
  refs.stepContent.querySelectorAll(".review-input").forEach((input) => {
    input.addEventListener("blur", () => {
      const idx = Number(input.dataset.index);
      const c = activeCase();
      c.ocrFields[idx].human = input.value;
    });
  });

  refs.stepContent.querySelectorAll("[data-action]").forEach((btn) => {
    btn.addEventListener("click", () => handleAction(btn.dataset.action));
  });

  const caseItemSelect = document.getElementById("caseItemSelect");
  if (caseItemSelect) {
    caseItemSelect.addEventListener("change", () => {
      const c = activeCase();
      const tpl = scenarioTemplates.find((x) => x.no === Number(caseItemSelect.value));
      if (!tpl) return;
      applyTemplateToCase(c, tpl, true);
      c.timeline.push({ at: "2026-02-22 21:50", by: c.owner, action: `切換項目模板為 ${templateLabel(tpl)}` });
      renderSummary();
      renderStepContent();
      renderTemplateCatalogPanel(tpl.no);
      showToast("已切換項目模板");
    });
  }
}

function handleAction(action) {
  const c = activeCase();

  if (action === "saveDraft") {
    c.timeline.push({ at: "2026-02-22 21:45", by: c.owner, action: "儲存建案草稿" });
    showToast("已儲存草稿");
  }

  if (action === "mockUpload") {
    const pending = c.docs.find((d) => d.scan === "待上傳");
    if (pending) {
      pending.scan = "通過";
      pending.at = "2026-02-22 21:50";
      pending.uploader = c.owner;
    } else {
      c.docs.push({
        name: "新增附件_" + (c.docs.length + 1) + ".pdf",
        uploader: c.owner,
        at: "2026-02-22 21:50",
        scan: "通過",
        type: "補充文件"
      });
    }
    c.timeline.push({ at: "2026-02-22 21:50", by: c.owner, action: "新增上傳 1 份文件" });
    showToast("已新增模擬附件");
    renderStepContent();
  }

  if (action === "rerunOCR") {
    c.timeline.push({ at: "2026-02-22 21:45", by: "系統", action: "重新執行 OCR" });
    showToast("已觸發 OCR 重跑");
  }

  if (action === "rerunRules") {
    c.timeline.push({ at: "2026-02-22 21:45", by: "系統", action: "重新執行規則判斷" });
    showToast("已重新判斷規則");
  }

  if (action === "saveReview") {
    const reason = document.getElementById("editReason")?.value || "手動調整欄位";
    c.timeline.push({ at: "2026-02-22 21:45", by: c.owner, action: `儲存人工覆核 (${reason})` });
    showToast("覆核內容已儲存");
  }

  if (action === "requestFix") {
    c.status = "退補件";
    c.currentStep = 1;
    c.timeline.push({ at: "2026-02-22 21:45", by: c.owner, action: "退補件：請補充或修正文件" });
    showToast("案件已退補件");
    renderAll();
  }

  if (action === "confirmArchive") {
    c.status = "已確認";
    c.currentStep = 6;
    c.syncs = c.syncs.map((s) => ({
      ...s,
      status: "ok",
      detail: s.target === "Email 管理" ? "已寄送通知（追蹤碼 EM-5721）" : "已回寫成功"
    }));
    c.timeline.push({ at: "2026-02-22 21:45", by: c.owner, action: "確認存檔並鎖定版本" });
    showToast("案件已確認存檔");
    renderAll();
  }

  if (action === "retrySync") {
    c.syncs = c.syncs.map((s) => ({ ...s, status: "ok", detail: "重送成功" }));
    c.timeline.push({ at: "2026-02-22 21:45", by: "系統", action: "重送同步任務成功" });
    showToast("同步任務已重送");
    renderStepContent();
  }
}

function renderAll() {
  const c = activeCase();
  if (activeStep > workflowSteps.length - 1) activeStep = workflowSteps.length - 1;
  c.currentStep = activeStep;
  renderCaseCards();
  renderSummary();
  renderStepper();
  renderStepContent();
  renderTemplateCatalogPanel(templateByCaseItem(c.item).no);
  refs.prevStepBtn.disabled = activeStep === 0;
  refs.nextStepBtn.disabled = activeStep === workflowSteps.length - 1;
}

function bindGlobalEvents() {
  refs.prevStepBtn.addEventListener("click", () => {
    if (activeStep > 0) {
      activeStep -= 1;
      renderAll();
    }
  });

  refs.nextStepBtn.addEventListener("click", () => {
    if (activeStep < workflowSteps.length - 1) {
      activeStep += 1;
      renderAll();
    }
  });

  refs.createCaseBtn.addEventListener("click", () => {
    const defaultTpl = scenarioTemplates[0];
    const newCase = {
      id: `CASE-2026-00${String(cases.length + 40).padStart(3, "0")}`,
      item: templateLabel(defaultTpl),
      applicant: "新申請人",
      owner: "GA 承辦新",
      amount: "0",
      status: "草稿",
      currentStep: 0,
      docs: defaultTpl.docs.map((d, idx) => ({
        name: `${d}_${idx + 1}.pdf`,
        uploader: "尚未上傳",
        at: "-",
        scan: "待上傳",
        type: d
      })),
      ocrFields: defaultTpl.fields.map((f) => ({ field: f, ai: "-", confidence: 0.0, human: "" })),
      rules: defaultTpl.rules.map((r) => ({ name: r, status: "warn", note: "待 OCR 與規則引擎執行" })),
      syncs: [{ target: "福利平台", status: "pending", detail: "尚未觸發" }],
      timeline: [{ at: "2026-02-22 21:45", by: "GA 承辦新", action: "建立新案件" }]
    };
    cases.unshift(newCase);
    activeCaseId = newCase.id;
    activeStep = 0;
    renderAll();
    showToast("已建立新案件");
  });

  refs.tabBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      refs.tabBtns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      if (btn.dataset.mode === "operation") {
        refs.operationView.classList.add("active");
        refs.adminView.classList.remove("active");
      } else {
        refs.operationView.classList.remove("active");
        refs.adminView.classList.add("active");
      }
    });
  });

  if (refs.templateSelector) {
    refs.templateSelector.addEventListener("change", () => {
      renderTemplateCatalogPanel(Number(refs.templateSelector.value));
    });
  }
}

bindGlobalEvents();
renderAll();
